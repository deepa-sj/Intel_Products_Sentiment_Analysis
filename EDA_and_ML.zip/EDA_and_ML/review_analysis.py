import pandas as pd
import numpy as np
import re

# Step 1: Read the CSV file
df = pd.read_csv('cleaned_i714.csv')

# Step 2: Inspect the DataFrame
print("Original DataFrame:")
print(df.head())

# Step 3: Data Cleaning and Preparation
# Handle missing values (if any)
print("\nChecking for missing values:")
print(df.isnull().sum())

# Drop rows with any missing values
df.dropna(inplace=True)

# Drop unnecessary columns
print("\nDropping unnecessary columns...")
df.drop(['asin', 'verified', 'location_and_date'], axis=1, inplace=True)

# Clean text data
print("\nCleaning text data...")
def clean_text(text):
    text = text.lower()  # Convert to lowercase
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    # Add more cleaning steps as needed
    return text

df['clean_text'] = df['text'].apply(clean_text)

# Convert rating to binary sentiment
print("\nConverting rating to sentiment...")
df['sentiment'] = df['rating'].apply(lambda x: 'positive' if x >= 4 else 'negative')

# Step 4: Save cleaned data
print("\nSaving cleaned data to 'cleaned_data.csv'...")
df.to_csv('revieved_i714.csv', index=False)

print("\nCleaning and processing completed!")

# Optional: Display the cleaned DataFrame
print("\nCleaned DataFrame:")
print(df.head())
