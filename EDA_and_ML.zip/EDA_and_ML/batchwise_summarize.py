import pandas as pd
from transformers import pipeline
import spacy
import traceback

def load_reviews(file_path):
    """
    Load reviews from a CSV file.
    """
    return pd.read_csv(file_path)

def analyze_review(review, summarizer, sentiment_analyzer):
    """
    Analyze a single review to extract what users like, dislike, and suggest.
    """
    max_length = 512
    truncated_review = review[:max_length]

    try:
        summary = summarizer(truncated_review, max_length=50, min_length=25, do_sample=False)[0]['summary_text']
        sentiment = sentiment_analyzer(truncated_review)[0]

        likes, dislikes, suggestions = "", "", ""

        if sentiment['label'] == 'POSITIVE':
            likes = summary
        else:
            dislikes = summary

        nlp = spacy.load('en_core_web_sm')
        doc = nlp(review)
        for sentence in doc.sents:
            sentiment_label = sentiment_analyzer(sentence.text)[0]['label']

            if any(word in sentence.text.lower() for word in ['should', 'could', 'would', 'recommend', 'suggest', 'improve']):
                suggestions += sentence.text.strip() + " "
            elif sentiment_label == 'NEGATIVE' and len(sentence.text.split()) > 5:  # Check for longer negative sentences
                dislikes += sentence.text.strip() + " "

        return likes, dislikes, suggestions.strip()

    except Exception as e:
        print(f"Error analyzing review: {e}")
        traceback.print_exc()
        return "", "", ""

def process_reviews(df):
    """
    Process all reviews in the DataFrame.
    """
    try:
        summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")
        sentiment_analyzer = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")

        likes_list, dislikes_list, suggestions_list = [], [], []

        for review in df['text']:
            likes, dislikes, suggestions = analyze_review(review, summarizer, sentiment_analyzer)
            likes_list.append(likes)
            dislikes_list.append(dislikes)
            suggestions_list.append(suggestions)

        df['likes'] = likes_list
        df['dislikes'] = dislikes_list
        df['suggestions'] = suggestions_list

        return df

    except Exception as e:
        print(f"Error processing reviews: {e}")
        traceback.print_exc()
        return pd.DataFrame()

def chunk_text(text, chunk_size=500):
    """
    Chunk text into smaller parts.
    """
    words = text.split()
    for i in range(0, len(words), chunk_size):
        yield " ".join(words[i:i+chunk_size])

def summarize_long_text(text, summarizer):
    """
    Summarize long text by chunking and summarizing each chunk.
    """
    try:
        chunks = list(chunk_text(text))
        summaries = [summarizer(chunk, max_length=50, min_length=25, do_sample=False)[0]['summary_text'] for chunk in chunks]
        combined_summary = " ".join(summaries)
        final_summary = summarizer(combined_summary, max_length=150, min_length=50, do_sample=False)[0]['summary_text']
        return final_summary

    except Exception as e:
        print(f"Error summarizing long text: {e}")
        traceback.print_exc()
        return ""

def extract_bullet_points(text, num_points=5):
    """
    Extract key points from text and format them as bullet points.
    """
    sentences = text.split('.')
    key_points = sentences[:num_points]
    bullet_points = "\n".join([f"- {point.strip()}" for point in key_points if point.strip()])
    return bullet_points

def summarize_sections(df):
    """
    Summarize the likes, dislikes, and suggestions sections into a few sentences.
    """
    try:
        summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")

        likes_summary = summarize_long_text(" ".join(df['likes'].dropna()), summarizer)
        dislikes_summary = summarize_long_text(" ".join(df['dislikes'].dropna()), summarizer)
        suggestions_summary = summarize_long_text(" ".join(df['suggestions'].dropna()), summarizer)

        likes_bullets = extract_bullet_points(likes_summary)
        dislikes_bullets = extract_bullet_points(dislikes_summary)
        suggestions_bullets = extract_bullet_points(suggestions_summary)

        return likes_bullets, dislikes_bullets, suggestions_bullets

    except Exception as e:
        print(f"Error summarizing sections: {e}")
        traceback.print_exc()
        return "", "", ""

def save_summary(df, output_file, likes_summary, dislikes_summary, suggestions_summary):
    """
    Save the processed reviews to a new CSV file along with summaries.
    """
    try:
        summary = {
            "Likes": likes_summary,
            "Dislikes": dislikes_summary,
            "Suggestions": suggestions_summary
        }
        summary_df = pd.DataFrame([summary])
        summary_df.to_csv(output_file, index=False)
        print(f"Summary saved successfully to {output_file}")

    except Exception as e:
        print(f"Error saving summary: {e}")
        traceback.print_exc()

# Specify the input CSV file location
input_file = 'clustered_reviews_i7_13.csv'  # Update this with the actual path to your input CSV file
# Specify the output CSV file location
output_file = 'processed_reviews_summary_i7_13.csv'  # Update this with the desired path for the output CSV file

df = load_reviews(input_file)
processed_df = process_reviews(df)
likes_summary, dislikes_summary, suggestions_summary = summarize_sections(processed_df)
save_summary(processed_df, output_file, likes_summary, dislikes_summary, suggestions_summary)

print("Processing completed.")