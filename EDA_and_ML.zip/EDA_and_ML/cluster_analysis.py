import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Step 1: Load your data
input_file = 'cleaned_data_.csv'  # Update this with the actual path to your input CSV file
df = pd.read_csv(input_file)

# Step 2: Vectorize text data
vectorizer = TfidfVectorizer(max_df=0.5, min_df=2, stop_words='english')
X = vectorizer.fit_transform(df['text'].values.astype('U'))  # Use the 'text' column for vectorization
terms = vectorizer.get_feature_names_out()

# Step 3: Apply K-Means clustering
n_clusters = 3  # Example: Choose an appropriate number of clusters
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
kmeans.fit(X)

# Step 4: Assign clusters and evaluate (optional)
df['cluster'] = kmeans.labels_
silhouette_avg = silhouette_score(X, kmeans.labels_)
print(f"Silhouette Score: {silhouette_avg}")

# Step 5: Check for 'sentiment' column
if 'sentiment' not in df.columns:
    print("'sentiment' column not found in the DataFrame. Adding a default 'sentiment' column.")
    df['sentiment'] = None  # Or handle as per your requirement

# Step 6: Extract the desired columns
output_df = df[['text', 'sentiment', 'cluster']]

# Step 7: Save results to a CSV file
output_file = 'clustered_reviews_.csv'  # Update this with the desired path for the output CSV file
output_df.to_csv(output_file, index=False)
print(f"Clustered data saved to {output_file}")
