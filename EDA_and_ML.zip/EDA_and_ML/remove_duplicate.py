import pandas as pd
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

# Load the dataset
input_file = 'Intel\dataset.csv'  # Replace with your input CSV file path
output_file = 'cleaned_i3_12.csv'  # Replace with your desired output CSV file path

# Read the CSV file into a DataFrame
df = pd.read_csv(input_file)

# Function to find duplicates based on fuzzy matching
def find_duplicates(df, column, threshold=90):
    duplicates = []
    for i, row in df.iterrows():
        for j, compare_row in df.iterrows():
            if i >= j:
                continue
            if fuzz.ratio(row[column], compare_row[column]) > threshold:
                duplicates.append(j)
    return set(duplicates)

# Identify duplicates based on the 'text' column with a similarity threshold of 90
duplicates = find_duplicates(df, 'text', threshold=90)

# Drop identified duplicate rows
df_cleaned = df.drop(duplicates)

# Save the cleaned DataFrame to a new CSV file
df_cleaned.to_csv(output_file, index=False)

print(f"Duplicate rows removed. Cleaned data saved to {output_file}")
